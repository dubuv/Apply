package com.example.ble;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import android.view.View;
import android.widget.TextView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private BluetoothAdapter bluetoothAdapter;
    private static final int REQUEST_PERMISSION_CODE = 1;
    private final List<BluetoothGatt> bluetoothGattList = new ArrayList<>();
    private static final String TAG = "BLE";

    private TextView hm10Device1Text;
    private TextView hm10Device2Text;
    private BluetoothGattCharacteristic commandCharacteristic;
    private ActivityResultLauncher<Intent> enableBluetoothLauncher;
    private Button sendCommandButton;
    private BluetoothManager bluetoothManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bluetoothManager = (BluetoothManager) getSystemService(BLUETOOTH_SERVICE);
        sendCommandButton = findViewById(R.id.sendCommandButton);
        sendCommandButton.setEnabled(false);

        hm10Device1Text = findViewById(R.id.hm10Device1Text);
        hm10Device2Text = findViewById(R.id.hm10Device2Text);

        if (hm10Device1Text.getVisibility() != View.VISIBLE) {
            hm10Device1Text.setVisibility(View.VISIBLE);  // 가시성 설정
        }
        if (hm10Device2Text.getVisibility() != View.VISIBLE) {
            hm10Device2Text.setVisibility(View.VISIBLE);  // 가시성 설정
        }

        bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter == null) {
            Log.e(TAG, "Bluetooth is not available");
            finish();
        }

        enableBluetoothLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        Log.i(TAG, "Bluetooth enabled");
                        startScan();
                    } else {
                        Log.e(TAG, "Bluetooth not enabled");
                        finish();
                    }
                }
        );

        requestPermissions();
        sendCommandButton.setOnClickListener(v -> sendCommand());
    }

    private void requestPermissions() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_PERMISSION_CODE);
        } else {
            enableBluetooth();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                enableBluetooth();
            } else {
                Log.e(TAG, "Location permission denied");
                finish();
            }
        }
    }

    private void enableBluetooth() {
        if (bluetoothAdapter == null) {
            Log.e(TAG, "Bluetooth is not supported on this device");
            return;
        }

        if (!bluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            enableBluetoothLauncher.launch(enableBtIntent);
        } else {
            Log.i(TAG, "Bluetooth is already enabled");
            startScan();
        }
    }

    @SuppressLint("MissingPermission")
    private void startScan() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e(TAG, "Location permission not granted");
            return;
        }
        BluetoothLeScanner bluetoothLeScanner = bluetoothAdapter.getBluetoothLeScanner();
        Log.i(TAG, "Starting Bluetooth scan for HM-10 devices...");
        bluetoothLeScanner.startScan(new ScanCallback() {

            @Override
            public void onScanResult(int callbackType, ScanResult result) {
                BluetoothDevice device = result.getDevice();
                if (ActivityCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                if (device.getName() != null && device.getName().contains("HM10_S2")) {
                    Log.i(TAG, "Found HM-10 : " + device.getName() + " (" + device.getAddress() + ")");

                    boolean alreadyConnected = false;
                    for (BluetoothGatt gatt : bluetoothGattList) {
                        if (gatt.getDevice().getAddress().equals(device.getAddress())) {
                            alreadyConnected = true;
                            break;
                        }
                    }
                    if (!alreadyConnected) {
                        connectToDevice(device);
                        if (bluetoothGattList.size() >= 2) {
                            bluetoothLeScanner.stopScan(this);
                            Log.i(TAG, "Stopped scanning after connecting to two devices");
                        }
                    }
                } else {
                    Log.d(TAG, "Scanned device: " + (device.getName() != null ? device.getName() : "Unknown") + " (" + device.getAddress() + ")");
                }
            }

            @Override
            public void onScanFailed(int errorCode) {
                Log.e(TAG, "Scan failed with error: " + errorCode);
            }
        });
    }

    @SuppressLint("MissingPermission")
    private void connectToDevice(BluetoothDevice device) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return;
        }
        for (BluetoothGatt gatt : bluetoothGattList) {
            if (gatt.getDevice().getAddress().equals(device.getAddress())) {
                Log.i(TAG, "Device already connected: " + device.getAddress());
                return;
            }
        }
        BluetoothGatt bluetoothGatt = device.connectGatt(this, true, new BluetoothGattCallback() {
            @Override
            public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                Log.i(TAG, "Connection state changed: " + newState + " for device: " + gatt.getDevice().getAddress());
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    Log.i(TAG, "Connected to GATT server: " + gatt.getDevice().getAddress());
                    bluetoothGattList.add(gatt);
                    gatt.discoverServices();
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    Log.i(TAG, "Disconnected from GATT server: " + gatt.getDevice().getAddress());
                    gatt.close();
                    bluetoothGattList.remove(gatt);
                    reconnectDevice(gatt.getDevice());
                }
            }

            @Override
            public void onServicesDiscovered(BluetoothGatt gatt, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    Log.i(TAG, "GATT services discovered for device: " + gatt.getDevice().getAddress());
                    BluetoothGattService service = gatt.getService(UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB"));
                    if (service != null) {
                        commandCharacteristic = service.getCharacteristic(UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"));
                        if (commandCharacteristic != null) {
                            gatt.setCharacteristicNotification(commandCharacteristic, true);

                            BluetoothGattDescriptor descriptor = commandCharacteristic.getDescriptor(UUID.fromString("00002902-0000-1000-8000-00805F9B34FB"));
                            if (descriptor != null) {
                                descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
                                gatt.writeDescriptor(descriptor);
                            }
                            runOnUiThread(() -> sendCommandButton.setEnabled(true));
                            Log.i(TAG, "Command characteristic initialized for device: " + gatt.getDevice().getAddress());
                        } else {
                            Log.e(TAG, "Command characteristic not found." + service.getCharacteristics());
                        }
                    } else {
                        Log.e(TAG, "Service not found." + gatt.getServices());
                    }
                } else {
                    Log.e(TAG, "Failed to discover services with status: " + status);
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
                String receivedData = new String(characteristic.getValue(), StandardCharsets.UTF_8);
                Log.d(TAG, "Received data: " + receivedData);

                String deviceAddress = gatt.getDevice().getAddress();
                runOnUiThread(() -> {
                    if ("9C1D5888BBEF".equals(deviceAddress)) {
                        // 첫 번째 모듈에서 수신한 데이터에 대해 처리
                        hm10Device1Text.setText("HM-10 모듈 1 데이터: " + processModule1Data(receivedData));
                    } else if ("F0B5D1A49157".equals(deviceAddress)) {
                        // 두 번째 모듈에서 수신한 데이터에 대해 처리
                        hm10Device2Text.setText("HM-10 모듈 2 데이터: " + processModule2Data(receivedData));
                    }
                });
            }

            // 첫 번째 모듈에 대한 데이터 처리 함수
            private String processModule1Data(String data) {
                if ("1".equals(data.trim())) {
                    return "1";
                }
                return "모듈 1에서 처리된 데이터: " + data;
            }

            // 두 번째 모듈에 대한 데이터 처리 함수
            private String processModule2Data(String data) {
                if ("1".equals(data.trim())) {
                    return "0";
                }
                return "모듈 2에서 처리된 데이터: " + data;
            }

            @Override
            public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    Log.i(TAG, "Write successful for characteristic: " + characteristic.getUuid());
                } else {
                    Log.e(TAG, "Failed to write characteristic: " + characteristic.getUuid() + " with status: " + status);
                }
            }
        });
        bluetoothGattList.add(bluetoothGatt);
    }

    private void reconnectDevice(BluetoothDevice device) {
        Log.i(TAG, "Attempting to reconnect to device: " + device.getAddress());
        connectToDevice(device);
    }

    @SuppressLint("MissingPermission")
    private void sendCommand() {
        for (BluetoothGatt gatt : bluetoothGattList) {
            BluetoothGattService service = gatt.getService(UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB"));
            if (service != null) {
                BluetoothGattCharacteristic characteristic = service.getCharacteristic(UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB"));
                if (characteristic != null) {
                    characteristic.setValue("1".getBytes(StandardCharsets.UTF_8));

                    int connectionState = bluetoothManager.getConnectionState(gatt.getDevice(), BluetoothProfile.GATT);
                    if (connectionState == BluetoothProfile.STATE_CONNECTED) {
                        boolean writeSuccess = gatt.writeCharacteristic(characteristic);
                        if (writeSuccess) {
                            Log.i(TAG, "Command sent successfully to device: " + gatt.getDevice().getAddress());
                        } else {
                            Log.e(TAG, "Failed to send command to device: " + gatt.getDevice().getAddress());
                        }
                    } else {
                        Log.e(TAG, "Device is not connected: " + gatt.getDevice().getAddress());
                    }
                }
            } else {
                Log.e(TAG, "No connected GATTs or characteristics to send command to.");
            }
        }
    }

    @SuppressLint("MissingPermission")
    @Override
    protected void onDestroy() {
        super.onDestroy();
        for (BluetoothGatt gatt : bluetoothGattList) {
            if (gatt != null) {
                gatt.disconnect();
                gatt.close();
            }
        }
        bluetoothGattList.clear();
    }
}
