package com.example.rescue;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Character extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_character);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.characterPage), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        showWelcomePopup();

        ImageView polarss = findViewById(R.id.polarss);
        ImageView otterss = findViewById(R.id.otterss);
        ImageView pandass = findViewById(R.id.pandass);

        polarss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionDialog("북극곰을 도와주러 가볼까요?", polar.class);
            }
        });

        otterss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionDialog("수달을 도와주러 가볼까요?", otter.class);
            }
        });

        pandass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDescriptionDialog("판다를 도와주러 가볼까요?", panda.class);
            }
        });
    }

    private void showWelcomePopup() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("환영합니다!");
        builder.setMessage("구조하고 싶은 동물을 골라주세요!");
        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss(); // 팝업 닫기
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show(); // 다이얼로그 표시
    }


private void showDescriptionDialog(String message, Class<?> targetActivity) {
    AlertDialog.Builder builder = new AlertDialog.Builder(this);
    builder.setTitle("");
    builder.setMessage("한번 선택한 동물은 끝까지 책임져야합니다!    구조하러 가볼까요?");
    builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss(); // 팝업 닫기
            // 다른 페이지로 이동
            Intent intent = new Intent(Character.this, targetActivity);
            startActivity(intent);
        }
    });

    builder.setNegativeButton("아니요", new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            dialog.dismiss(); // 팝업 닫기
            // 사용자가 다시 이미지를 선택할 수 있도록 아무 작업도 하지 않음
        }
    });
    AlertDialog dialog = builder.create();
    dialog.show(); // 다이얼로그 표시
}
}



