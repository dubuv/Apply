package com.example.rescue;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class otter extends AppCompatActivity {

    private ImageView apple, chicken, banana, otterbacks;
    private int imageCount = 0; // 초기화

    private static final int REQUEST_CODE = 1;

    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_otter);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.otter), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        apple = findViewById(R.id.apple);
        chicken = findViewById(R.id.chicken);
        banana = findViewById(R.id.banana);
        otterbacks = findViewById(R.id.otterbacks);

        Button scan = findViewById(R.id.scan_otter);
        scan.setOnClickListener(v -> {
            Intent intent = new Intent(otter.this, Scan.class);
            startActivityForResult(intent, REQUEST_CODE);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ImageUpdate", "onResume called");
        updateImages(); // 이미지를 업데이트하는 메소드 호출
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                imageCount++;
                Log.d("ImageUpdate", "imageCount after return: " + imageCount);
                updateImages(); // 이미지를 업데이트합니다.
            }
        }
    }

    private void updateImages() {
        // 이미지 가시성 설정
        if (imageCount == 0) {
            apple.setVisibility(View.VISIBLE);
            chicken.setVisibility(View.VISIBLE);
            banana.setVisibility(View.VISIBLE);
            otterbacks.setVisibility(View.GONE);
        } else if (imageCount == 1) {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.VISIBLE);
            banana.setVisibility(View.VISIBLE);
            otterbacks.setVisibility(View.GONE);
        } else if (imageCount == 2) {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.GONE);
            banana.setVisibility(View.VISIBLE);
            otterbacks.setVisibility(View.GONE);
        } else {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.GONE);
            banana.setVisibility(View.GONE);
            otterbacks.setVisibility(View.VISIBLE);

            // 이미지가 모두 사라진 후에만 다이얼로그 띄우기
            handler.postDelayed(this::showDialog, 3000); // 3초 후에 다이얼로그
        }

        Log.d("ImageUpdate", "imageCount: " + imageCount);
    }

    private void showDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("구조 성공!")
                .setMessage("동물들 주변의 쓰레기를 모두 치워주셨군요!")
                .show();

        // 3초 후 다이얼로그 자동 닫기와 버튼 생성
        new Handler().postDelayed(() -> {
            dialog.dismiss();
            createNewButton(); // 새 버튼 생성
        }, 3000);
    }

    // 새로운 버튼을 생성하는 메서드
    private void createNewButton() {
        Button newButton = new Button(this);
        newButton.setText("구조 끝내기");
        newButton.setTextSize(25);

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.WRAP_CONTENT,
                RelativeLayout.LayoutParams.WRAP_CONTENT
        );

        params.addRule(RelativeLayout.CENTER_IN_PARENT);

        newButton.setLayoutParams(params);


        // 버튼 클릭 시 다음 액티비티로 이동
        newButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, Ending.class); // 이동할 액티비티로 변경
            startActivity(intent);
        });

        // 생성한 버튼을 레이아웃에 추가
        ViewGroup layout = findViewById(R.id.otter); // 버튼을 추가할 레이아웃 ID로 변경
        layout.addView(newButton);
    }
}