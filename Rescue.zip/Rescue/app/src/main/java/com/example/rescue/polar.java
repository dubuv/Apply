package com.example.rescue;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class polar extends AppCompatActivity {

    private ImageView apple, chicken, banana, polarbacks;
    private int imageCount = 0; // 초기화

    private static final int REQUEST_CODE = 1;

    private Handler handler = new Handler();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_polar);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.polarbear), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        apple = findViewById(R.id.apple);
        chicken = findViewById(R.id.chicken);
        banana = findViewById(R.id.banana);
        polarbacks=findViewById(R.id.polarbacks);

        Button scan = findViewById(R.id.scan);
        scan.setOnClickListener(v -> {
            Intent intent = new Intent(polar.this, Scan.class);
            startActivityForResult(intent, REQUEST_CODE);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ImageUpdate", "onResume called");
        updateImages(); // 이미지를 업데이트하는 메소드 호출
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                imageCount++;
                Log.d("ImageUpdate", "imageCount after return: " + imageCount);
                updateImages(); // 이미지를 업데이트합니다.
            }
        }
    }

    private void updateImages() {
        // 이미지 가시성 설정
        if (imageCount == 0) {
            apple.setVisibility(View.VISIBLE);
            chicken.setVisibility(View.VISIBLE);
            banana.setVisibility(View.VISIBLE);
            polarbacks.setVisibility(View.GONE);
        } else if (imageCount == 1) {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.VISIBLE);
            banana.setVisibility(View.VISIBLE);
            polarbacks.setVisibility(View.GONE);
        } else if (imageCount == 2) {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.GONE);
            banana.setVisibility(View.VISIBLE);
            polarbacks.setVisibility(View.GONE);
        } else {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.GONE);
            banana.setVisibility(View.GONE);
            polarbacks.setVisibility(View.VISIBLE);

            // 이미지가 모두 사라진 후에만 다이얼로그 띄우기
            handler.postDelayed(this::showDialog, 3000); // 3초 후에 다이얼로그
        }

        Log.d("ImageUpdate", "imageCount: " + imageCount);
    }

    // AlertDialog를 띄우는 메소드
    private void showDialog() {
        new AlertDialog.Builder(this)
                .setTitle("성공!")
                .setMessage("동물들 주변의 쓰레기를 모두 치워주셨군요!")
                .setPositiveButton(android.R.string.ok, (dialog, which) -> {
                    // 버튼 클릭 시의 동작 추가 (필요 시)
                })
                .setNegativeButton(android.R.string.cancel, null) // 취소 버튼
                .show();
    }
}
