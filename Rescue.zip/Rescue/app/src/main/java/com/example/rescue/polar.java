package com.example.rescue;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class polar extends AppCompatActivity {

    private ImageView apple, chicken, banana;
    private int imageCount = 0; // 초기화

    private static final int REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_polar);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.polarbear), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        apple = findViewById(R.id.apple);
        chicken = findViewById(R.id.chicken);
        banana = findViewById(R.id.banana);

        Button scan = findViewById(R.id.scan);
        scan.setOnClickListener(v -> {
            Intent intent = new Intent(polar.this, Scan.class);
            startActivityForResult(intent, REQUEST_CODE);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ImageUpdate", "onResume called");
        updateImages(); // 이미지를 업데이트하는 메소드 호출
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                imageCount++;
                Log.d("ImageUpdate", "imageCount after return: " + imageCount);
                updateImages(); // 이미지를 업데이트합니다.
            }
        }
    }

    private void updateImages() {
        // 이미지 가시성 설정
        if (imageCount == 0) {
            apple.setVisibility(View.VISIBLE);
            chicken.setVisibility(View.VISIBLE);
            banana.setVisibility(View.VISIBLE);
        } else if (imageCount == 1) {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.VISIBLE);
            banana.setVisibility(View.VISIBLE);
        } else if (imageCount == 2) {
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.GONE);
            banana.setVisibility(View.VISIBLE);
        } else {
            apple.setVisibility(View.GONE);
            apple.setVisibility(View.GONE);
            chicken.setVisibility(View.GONE);
            banana.setVisibility(View.GONE);
        }

        Log.d("ImageUpdate", "imageCount: " + imageCount);
    }
}
